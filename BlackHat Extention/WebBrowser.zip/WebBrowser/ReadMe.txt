run it through command prompt or in eclipse

Hi, this is a osama mursleen from pakistan , doing bachelors in computer sciences 
from university of lahore...

This browser done in java.... i am just a beginner in java

if u wanna contact me contact me at : osamamursleen@gmail.com

i hope u like it.. thanks
