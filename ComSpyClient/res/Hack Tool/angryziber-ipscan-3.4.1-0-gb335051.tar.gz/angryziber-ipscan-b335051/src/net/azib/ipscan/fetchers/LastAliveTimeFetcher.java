/**
 * This file is a part of Angry IP Scanner source code,
 * see http://www.angryip.org/ for more information.
 * Licensed under GPLv2.
 */

package net.azib.ipscan.fetchers;

import net.azib.ipscan.core.ScanningSubject;

/**
 * LastAliveTimeFetcher
 *
 * TODO: implement LastAliveTimeFetcher
 *
 * @author Anton Keks
 */
public class LastAliveTimeFetcher extends AbstractFetcher {

	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object scan(ScanningSubject subject) {
		// TODO Auto-generated method stub
		return null;
	}

}
