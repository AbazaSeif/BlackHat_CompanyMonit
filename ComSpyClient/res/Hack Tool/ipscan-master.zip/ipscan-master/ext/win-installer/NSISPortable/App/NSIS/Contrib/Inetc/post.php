<html>
<head>
</head>
<body>
<?php
echo "post.login=".$_POST['login']."<br>";
echo "post.passwd=".$_POST['passwd']."<br>";
echo "get.lg=".$_GET['lg']."<br>";
echo "get.pw=".$_GET['pw']."<br>";
?>
</body>

</html>
