package org.krakenapps.sqlparser.ast;

public class DropColumnScopeClause implements AlterColumnAction {

}
