package org.krakenapps.sqlparser.ast;

public class AddColumnScopeClause implements AlterColumnAction {

}
