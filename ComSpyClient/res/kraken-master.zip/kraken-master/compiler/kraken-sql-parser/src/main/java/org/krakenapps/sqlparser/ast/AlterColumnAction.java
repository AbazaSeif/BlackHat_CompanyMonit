package org.krakenapps.sqlparser.ast;

public interface AlterColumnAction {

}
