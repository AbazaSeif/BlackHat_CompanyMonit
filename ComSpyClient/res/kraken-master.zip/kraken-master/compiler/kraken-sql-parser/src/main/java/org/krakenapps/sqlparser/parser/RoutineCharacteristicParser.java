package org.krakenapps.sqlparser.parser;

import org.krakenapps.bnf.Binding;
import org.krakenapps.bnf.Parser;

public class RoutineCharacteristicParser implements Parser {

	@Override
	public Object parse(Binding b) {
		// TODO Auto-generated method stub
		return null;
	}

}
