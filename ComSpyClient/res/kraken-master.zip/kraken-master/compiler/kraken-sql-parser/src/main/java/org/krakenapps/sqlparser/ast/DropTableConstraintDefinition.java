package org.krakenapps.sqlparser.ast;

public class DropTableConstraintDefinition implements AlterTableAction {

}
