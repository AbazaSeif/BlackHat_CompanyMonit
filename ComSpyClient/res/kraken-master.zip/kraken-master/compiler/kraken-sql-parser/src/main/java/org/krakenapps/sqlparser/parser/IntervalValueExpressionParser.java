package org.krakenapps.sqlparser.parser;

import org.krakenapps.bnf.Binding;
import org.krakenapps.bnf.Parser;

public class IntervalValueExpressionParser implements Parser {

	@Override
	public Object parse(Binding b) {
		// TODO Auto-generated method stub
		return null;
	}

}
