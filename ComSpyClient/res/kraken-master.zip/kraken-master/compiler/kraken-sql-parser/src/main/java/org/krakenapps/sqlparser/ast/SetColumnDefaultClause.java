package org.krakenapps.sqlparser.ast;

public class SetColumnDefaultClause implements AlterColumnAction {

}
