package org.krakenapps.sqlparser.ast;

public class AddTableConstraintDefinition implements AlterTableAction {

}
