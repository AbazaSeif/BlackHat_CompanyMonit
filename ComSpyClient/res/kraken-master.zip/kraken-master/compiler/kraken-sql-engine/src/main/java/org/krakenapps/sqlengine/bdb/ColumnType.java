package org.krakenapps.sqlengine.bdb;

public enum ColumnType {
	String, Integer, Timestamp
}
