package org.krakenapps.sqlengine;

public interface TableHandleEventListener {
	void onClose(TableHandle handle);
}
