package org.krakenapps.sqlengine;

public enum Status {
	Success, NotFound, KeyEmpty, KeyExist
}
