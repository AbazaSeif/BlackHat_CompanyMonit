package edu.huji.cs.netutils;

public class NetUtilsFragmentException extends RuntimeException
{

	public NetUtilsFragmentException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public NetUtilsFragmentException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NetUtilsFragmentException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NetUtilsFragmentException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
