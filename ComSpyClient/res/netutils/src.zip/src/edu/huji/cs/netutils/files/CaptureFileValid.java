package edu.huji.cs.netutils.files;

public interface CaptureFileValid
{
	boolean isValid();
}
