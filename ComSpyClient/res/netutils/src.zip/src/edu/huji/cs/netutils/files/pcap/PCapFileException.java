package edu.huji.cs.netutils.files.pcap;

public class PCapFileException extends Exception
{

	/**
	 * 
	 */
	public PCapFileException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param theArg0
	 * @param theArg1
	 */
	public PCapFileException(String theArg0, Throwable theArg1)
	{
		super(theArg0, theArg1);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param theArg0
	 */
	public PCapFileException(String theArg0)
	{
		super(theArg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param theArg0
	 */
	public PCapFileException(Throwable theArg0)
	{
		super(theArg0);
		// TODO Auto-generated constructor stub
	}
	
}
