/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TunnelThread extends Thread{

        private InputStream     is;
        private OutputStream    os;
        private String          name;

	TunnelThread (InputStream is, OutputStream os, String name) {
		this.is = is;
		this.os = os;
                this.name = name;
        }

        public void run () {

                byte buffer[] = new byte[1024];
                int cnt;
                try {
                        while ((cnt = is.read(buffer)) > 0) {
                                os.write(buffer, 0, cnt);
                                os.flush();
                                Logger.dump(name, buffer, 0, cnt);
                        }
                } 
                catch (IOException e) {} 
                finally {
                        try {
                                is.close();
                                os.close();
                        } 
                        catch (IOException e) {}
		}
                Logger.log(name + " - finished ");
	  }
          
}
