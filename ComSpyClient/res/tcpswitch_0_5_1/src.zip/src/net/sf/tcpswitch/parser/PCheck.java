/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch.parser;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import net.sf.tcpswitch.Config;
import net.sf.tcpswitch.ConnInfo;
import net.sf.tcpswitch.Logger;
import net.sf.tcpswitch.TCPSWException;

public class PCheck extends PStatement {

        private String var;
        private String op;
        private String value;
        private PStatementList statementList;
        
        private long num;
        
        public PCheck(String var, String op, String value, PStatementList statementList) throws TCPSWException {
                this.var = var;
                this.op = op;
                this.value = value;
                this.statementList = statementList;
                if ("#=#<#<=#>#>=#!=#".indexOf("#" + op + "#") == -1)
                        throw new TCPSWException("unknown operator " + op);
                if ("#protocol#ip#port#time#date#".indexOf("#" + var + "#") == -1)
                        throw new TCPSWException("unknown variable $" + var);
                if (var.equals("protocol")) {
                        if (!op.equals("="))
                                throw new TCPSWException("$protocol can only be checked for the operator '=' (was '" + op + "')");
                        if ("#HTTP#HTTPS#HTTPSPROXY#FTP#SSH#".indexOf("#" + value + "#") == -1)
                                throw new TCPSWException("unknown protocol " + value + " only HTTP, HTTPS, HTTPSPROXY, FTP, SSH allowed");
                }
                else if (var.equals("ip"))
                        num = ip2num(value);                        
                else if (var.equals("port"))
                        num = str2num(value);                        
                else if (var.equals("time"))
                        checkTime(value);                        
                else if (var.equals("date"))
                        checkDate(value);                        
        }

        private void checkTime(String timeStr) throws TCPSWException {
                
                if (!timeStr.matches("[0-9][0-9][:][0-9][0-9][:][0-9][0-9]"))
                        throw new TCPSWException("invalid time format (hh:mm:ss) " + timeStr);
        }

        private void checkDate(String dateStr) throws TCPSWException {
                
                if (!dateStr.matches("[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]"))
                        throw new TCPSWException("invalid date format (yyyy-mm-dd) " + dateStr);
        }

        private long ip2num(String ipStr) throws TCPSWException {
                
                String[] nums = ipStr.split("[.]");
                if (nums.length != 4)
                        throw new TCPSWException("not a valid ip '" + ipStr + "'");
                long ip = 0;
                try {
                        for (int i=0; i<4; i++)
                                ip = (ip << 8) + Integer.parseInt(nums[i]);
                } 
                catch (NumberFormatException e) {
                        throw new TCPSWException("not a valid ip '" + ipStr + "'");
                }
                return ip;
        }

        private long str2num(String numStr) throws TCPSWException {
                
                long result = -1;
                try {
                        result = Long.parseLong(numStr);
                } 
                catch (NumberFormatException e) {
                        throw new TCPSWException("not a valid number '" + numStr + "'");
                }
                return result;
        }



        private boolean checkCondition(ConnInfo conn) throws IOException, InterruptedException, TCPSWException {
                
                boolean result = false;
                if (var.equals("protocol")) {
                        if (value.equals("HTTP"))
                                result = conn.checkHTTP();
                        else if (value.equals("HTTPS"))
                                result = conn.checkHTTPS();
                        else if (value.equals("HTTPSPROXY"))
                                result = conn.checkHTTPSPROXY();
                        else if (value.equals("FTP")) {
                                String fwdHost = null;
                                int fwdPort = 0;
                                int status = conn.simulateFTPChecked();
                                if (status == 1)
                                        result = true;
                                else if (status == -1)
                                        result = false;
                                else {
                                        int fwstatus = statementList.forward(conn);
                                        if (fwstatus == PStatement.EX_NEXT)
                                                result = false;
                                        else if (fwstatus == PStatement.EX_QUIT)
                                                result = conn.checkFTP(Config.ftpWelcome);
                                        else {
                                                fwdHost = conn.getFwdHost();
                                                fwdPort = conn.getFwdPort();
                                                if (fwdPort == 0)
                                                        fwdPort = 21;
                                                conn.setForward(null, 0, null);
                                        }
                                }
                                conn.endSimulateChecked();
                                if (fwdHost != null) {
                                        String welcome = getWelcome(fwdHost, fwdPort);
                                        result = conn.checkFTP(welcome);
                                }
                        }
                        else if (value.equals("SSH")) {
                                String fwdHost = null;
                                int fwdPort = 0;
                                int status = conn.simulateSSHChecked();
                                if (status == 1)
                                        result = true;
                                else if (status == -1)
                                        result = false;
                                else {
                                        int fwstatus = statementList.forward(conn);
                                        if (fwstatus == PStatement.EX_NEXT)
                                                result = false;
                                        else if (fwstatus == PStatement.EX_QUIT)
                                                result = conn.checkFTP(Config.sshWelcome);
                                        else {
                                                fwdHost = conn.getFwdHost();
                                                fwdPort = conn.getFwdPort();
                                                if (fwdPort == 0)
                                                        fwdPort = 22;
                                                conn.setForward(null, 0, null);
                                        }
                                }
                                conn.endSimulateChecked();
                                if (fwdHost != null) {
                                        String welcome = getWelcome(fwdHost, fwdPort);
                                        result = conn.checkSSH(welcome);
                                }
                        }
                        else 
                                throw new TCPSWException("unknown protocol " + value);
                }
                else if (var.equals("ip"))
                        result = checkNum(conn.getIP());
                else if (var.equals("port"))
                        result = checkNum(conn.getPort());
                else if (var.equals("time"))
                        result = checkStr(getCurrentTime());
                else if (var.equals("date"))
                        result = checkStr(getCurrentDate());
                else
                        throw new TCPSWException("unknown variable " + var);
                return result;
        }


        private boolean checkNum(long n) throws TCPSWException {
                
                boolean result;
                if (op.equals("="))
                        result = (n == num);
                else if (op.equals("<"))
                        result = (n < num);
                else if (op.equals("<="))
                        result = (n <= num);
                else if (op.equals(">"))
                        result = (n > num);
                else if (op.equals(">="))
                        result = (n >= num);
                else if (op.equals("!="))
                        result = (n != num);
                else
                        throw new TCPSWException("unknown operator " + op);
                return result;
        }

        private boolean checkStr(String compStr) throws TCPSWException {
                
                int cmp = compStr.compareTo(value);
                num = 0;
                return checkNum(cmp);
        }

        private String getCurrentTime() {
                
                Date now = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                String result = sdf.format(now);
                return result; 
        }

        private String getCurrentDate() {
                
                Date now = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String result = sdf.format(now);
                return result; 
        }

        private static HashMap welcomeCache = new HashMap();
        private static String getWelcome(String fwdHost, int fwdPort) {

                String result = null;                
                String key = fwdHost + ":" + Integer.toString(fwdPort);
                synchronized (welcomeCache) {
                        result = (String)welcomeCache.get(key);
                }
                if (result == null) {
                        result = ConnInfo.getFirstData(fwdHost, fwdPort, 50);
                        synchronized (welcomeCache) {
                                welcomeCache.put(key, result);
                        }
                }
                return result;
        }

        private int getPort(String hostPort, int defaultPort) {
                
                int result;
                String[] host_port = hostPort.split("[:]");
                if (host_port.length <2)
                        result = defaultPort;
                else
                        result = Integer.parseInt(host_port[1]);
                return result;
        }

        private String getHost(String hostPort) {

                String result;
                String[] host_port = hostPort.split("[:]");
                result = host_port[0];
                return result;
        }

        public int forward(ConnInfo conn) {

                int result = EX_NEXT;
                try {
                        if (checkCondition(conn)) {
                                result = statementList.forward(conn);
                        }
                } catch (Exception e) {
                        e.printStackTrace();
                        Logger.err("forwarderror: " + e.getMessage());
                }
                return result;
        }

        public String show(String indent) {
                StringBuffer result = new StringBuffer();
                result.append(indent + "check ($" + var + op  + value + ") {\n");
                result.append(statementList.show(indent + "  "));
                result.append(indent + "}\n");
                return result.toString();
        }

}
