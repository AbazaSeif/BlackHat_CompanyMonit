/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {


        public static void init() {
                initHexBytes();
        }

        public static synchronized void log(String msg) {
                String time = getNow();
                String threadName = Thread.currentThread().getName();
                System.out.println("[" + time + " - " + threadName + "]: " + msg);
        }
        public static synchronized void err(String msg) {
                String time = getNow();
                String threadName = Thread.currentThread().getName();
                System.err.println("[" + time + " - " + threadName + "]: " + msg);
        }
        
        private static SimpleDateFormat sdf = null;
        private static String getNow() {
                Date now = new Date();
                if (sdf == null)
                        sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String result = sdf.format(now);
                return result;
        }

        public static void debug(String msg) {
                if (Config.debug) 
                        log(msg);
        }



        public static String[] hexBytes = null;
        public static char[] printChar = null;
        public static String hex = "0123456789abcdef";

        private static void initHexBytes() {
                
                if (hexBytes == null) {
                        hexBytes = new String[256];
                        for (int i=0; i<16; i++) {
                               String h1 = hex.substring(i, i+1);
                                for (int j=0; j<16; j++) {
                                        String h2 = hex.substring(j, j+1);
                                        hexBytes[i*16 + j] = h1 + h2;
                                }
                        }
                        printChar = new char[256];
                        for (int i=0; i<256; i++) {
                                if ((i<32) || ((i>=128) && (i <= 160)))
                                        printChar[i] = '.';
                                else 
                                        printChar[i] = (char) i;
                        }
                }
        }
          
        private static String hexText(byte[] buf, int from, int len) {

                initHexBytes();
                StringBuffer line = new StringBuffer(24);
                StringBuffer result = new StringBuffer(len * 5);
                int cnt = 0;
                for (int i=0; i<len; i++) {
                        int n = (int) buf[from + i];
                        if (n<0)
                                n = 256 + n;
                        String hex = hexBytes[n];
                        result.append(hex).append(' ');
                        line.append(printChar[n]);
                        cnt += 1;
                        if (cnt == 24) {
                                result.append(" : ").append(line).append('\n');
                                line.setLength(0);
                                cnt = 0;
                        }
                }
                if (cnt != 0) {                        
                        for (int i=cnt; i<24; i++) 
                                result.append("   ");
                        result.append(" : ").append(line).append('\n');
                }
                return result.toString();
        }


        public static void dump(String msg, byte[] buf, int from, int len) {

                if (Config.debug) {
                        String dumpText = hexText(buf, from, len);
                        Logger.debug(msg + "\r\n" + dumpText);
                }
        }


}
