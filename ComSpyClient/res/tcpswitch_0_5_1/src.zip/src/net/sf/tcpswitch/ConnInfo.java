/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;

public class ConnInfo {

        private static WeakHashMap usedConnections = new WeakHashMap();

        final static int PR_HTTP        =  1;
        final static int PR_HTTPS       =  2;
        final static int PR_HTTPSPROXY  =  4;
        final static int PR_FTP         =  8;
        final static int PR_SSH         = 16;

        Socket clientSocket;
        Socket forwardSocket;
        InputStream cin;
        OutputStream cout;
        InetAddress remoteAddr;
        long remoteIP = -1;
        int remotePort;
        String remoteInfo;
        HashMap params;
        
        private String proxyHost = null;
        private int proxyPort = -1;
        
        private String forwardHost = null;
        private int forwardPort = -1;
        private String forwardOptions = null;

        int checked_protocols = 0;
        int protocol = 0;

        byte[] peek = null;

        boolean skipFirstServerData = false;
                                    
        public ConnInfo(Socket socket) throws IOException {

                clientSocket = socket;
                cin = clientSocket.getInputStream();
                cout = clientSocket.getOutputStream();
                remoteAddr = clientSocket.getInetAddress();
                remotePort = clientSocket.getPort();
                remoteInfo = "?:" + remotePort;
                if (remoteAddr != null) {
                        if (Config.loghostname) 
                                remoteInfo = remoteAddr.getHostAddress() + ":" + remotePort;
                        else
                                remoteInfo = remoteAddr.getHostAddress() + "(" + remoteAddr.getHostName() + ")" + ":" + remotePort;
                }
                params = new HashMap();
        }
        
        public boolean checkHTTP() throws IOException, InterruptedException {

                if (protocol == PR_HTTP)
                        return true;
                if (protocol != 0)
                        return false;
                if ((checked_protocols & PR_HTTP) != 0)
                        return false;
                byte[] buf = peekInput(30);
                String input = new String(buf);
                boolean ok = input.startsWith("GET") || input.startsWith("POST");
                if (ok)
                        protocol = PR_HTTP;
                checked_protocols |= PR_HTTP;
                return ok;
        }

        public boolean checkHTTPS() throws IOException, InterruptedException {

                if (protocol == PR_HTTPS)
                        return true;
                if (protocol != 0)
                        return false;
                if ((checked_protocols & PR_HTTPS) != 0)
                        return false;
                byte[] buf = peekInput(30);
                boolean ok = (buf.length > 0);
                if (ok) {
                        String input = new String(buf);
                        ok = !(input.startsWith("GET") || input.startsWith("POST"));
                }
                if (ok)
                        protocol = PR_HTTPS;
                checked_protocols |= PR_HTTPS;
                return ok;
        }

        public boolean checkHTTPSPROXY() throws IOException, InterruptedException {
                if (protocol == PR_HTTPSPROXY)
                        return true;
                if (protocol != 0)
                        return false;
                if ((checked_protocols & PR_HTTPSPROXY) != 0)
                        return false;
                byte[] buf = peekInput(30);
                String input = new String(buf);
                String flat = flatten(input);
                boolean ok = flat.matches("[cC][oO][nN][nN][eE][cC][tT]\\s\\S+[:][0-9]+.*");
                if (ok) {
                        protocol = PR_HTTPSPROXY;
                        proxyHost = flat.replaceFirst("[cC][oO][nN][nN][eE][cC][tT]\\s(\\S+)[:]([0-9])+.*", "$1");
                        String port = flat.replaceFirst("[cC][oO][nN][nN][eE][cC][tT]\\s(\\S)+[:]([0-9]+).*", "$2");
                        try {
                                proxyPort = Integer.parseInt(port);
                        } catch (NumberFormatException e) {
                                Logger.err("HTTPSPROXY with invalid port: " + input);
                                ok = false;
                                proxyHost = null;
                        }
                }
                if (ok) {
                        resetPeek();
                }
                checked_protocols |= PR_HTTPSPROXY;
                return ok;
        }

        private String flatten(String text) {

                byte[] flatBytes = text.getBytes();
                for (int i=0; i<flatBytes.length; i++) {
                        if ((flatBytes[i] == '\r') || (flatBytes[i] == '\n'))
                                flatBytes[i] = ' ';
                }
                String result = new String(flatBytes);
                return result;
        }

        public int simulateFTPChecked() {
                if (protocol == PR_FTP) 
                        return 1;
                if (protocol != 0) 
                        return -1;
                protocol = PR_FTP;
                return 0;
        }
        public int simulateSSHChecked() {
                if (protocol == PR_SSH) 
                        return 1;
                if (protocol != 0) 
                        return -1;
                protocol = PR_SSH;
                return 0;
        }
        public void endSimulateChecked() {
                protocol = 0;
        }



        public boolean checkFTP(String welcome) throws IOException, InterruptedException {

                if (protocol == PR_FTP)
                        return true;
                if (protocol != 0)
                        return false;
                if ((checked_protocols & PR_FTP) != 0)
                        return false;
                if ((checked_protocols & PR_SSH) != 0) {
                        Logger.err("ERROR: checking FTP after SSH, change order of rules");
                        return false;
                }
                // wait 3 seconds before sending server welcome
                byte[] buf = peekInput(30);
                boolean ok = buf.length == 0;
                if (ok) {
                        sendData(welcome.getBytes());
                        resetPeek();
                        // 5 seconds to log in
                        buf = peekInput(50);
                        ok = buf.length > 0;
                }
                if (ok)
                        protocol = PR_FTP;
                checked_protocols |= PR_FTP;
                skipFirstServerData = true;
                return ok;
        }

        public boolean checkSSH(String welcome) throws IOException, InterruptedException {

                if (protocol == PR_SSH)
                        return true;
                if (protocol != 0)
                        return false;
                if ((checked_protocols & PR_SSH) != 0)
                        return false;
                // wait 3 seconds before sending server welcome
                byte[] buf = peekInput(30);
                boolean ok = buf.length == 0;
                if (ok) {
                        sendData(welcome.getBytes());
                        resetPeek();
                        // 5 seconds to log in
                        buf = peekInput(30);
                        ok = buf.length > 0;
                }
                if (ok)
                        protocol = PR_SSH;
                checked_protocols |= PR_SSH;
                skipFirstServerData = true;
                return ok;
        }

        public void rewriteHTTP() throws IOException, InterruptedException {
                
                String host = forwardHost;
                if (forwardPort != 80)
                        host += ":" + forwardPort;
                String input = new String(peekInput(30));        
                String rewrittenHandshake = input.replaceFirst("Host:\\s*\\S+", "Host: " + host);
                Logger.debug("rewrittenHeader=\r\n" + rewrittenHandshake);
                setPeek(rewrittenHandshake.getBytes());
        }


        private void resetPeek() {
                peek = null;
        }
        private void setPeek(byte[] buf) {
                peek = buf;
        }
        /**
         * only wait if peek was reset 
         * @param wait in tenth secons
         * @return
         */
        private byte[] peekInput(int wait) throws IOException, InterruptedException {
        
                if (peek == null) {        
                        int cnt = wait;
                        while (cin.available() == 0) {
                                Thread.sleep(100);
                                cnt -= 1;
                                if (cnt == 0)
                                        break;
                        }
                        peek = new byte[cin.available()];
                        if (cin.available() > 0)
                                cin.read(peek);
                }
                Logger.dump("peekInput", peek, 0, peek.length);
                return peek;
        }
        
        private static byte[] receiveData(InputStream in, int wait) throws IOException, InterruptedException {
        
                byte[] result = null;
                int cnt = wait;
                while (in.available() == 0) {
                        Thread.sleep(100);
                        cnt -= 1;
                        if (cnt == 0)
                                break;
                }
                result = new byte[in.available()];
                if (in.available() > 0)
                        in.read(result);
                Logger.dump("receiveData", result, 0, result.length);
                return result;
        }
        
        private void sendData(byte[] buf) throws IOException {
                cout.write(buf);                
                Logger.dump("sendData", buf, 0, buf.length);
        }

        public static String getFirstData(String host, int port, int wait) {

                String result = null;
                byte[] buf;
                try {
                        Socket st = new Socket(host, port);
                        InputStream sin = st.getInputStream();
                        OutputStream sout = st.getOutputStream();
                        buf = receiveData(sin, wait);
                        sout.close();
                        sin.close();
                        st.close();
                        result = new String(buf);
                } catch (Exception e) {
                        Logger.err("getFirstData(" + host + ", " + port + "): error=" + e.getMessage());
                }
                return result; 
        }

        void forward() throws TCPSWException, IOException, InterruptedException {

                if (forwardHost == null)
                        throw new TCPSWException("forward host not set");

                if ((forwardOptions!=null) && (forwardOptions.equals("HTTPSPROXYestablish"))) {
                        String okMsg = replaceAll(Config.proxyEstablished, "${date}", getNowString());
                        sendData(okMsg.getBytes());
                }

                if ((forwardOptions!=null) && (forwardOptions.startsWith("HTTPSPROXYconnect"))) {
                        String connectHost = forwardOptions.replaceFirst("HTTPSPROXYconnect\\s*[(]\\s*(\\S+)[:]([0-9]+)\\s*[)]\\s*", "$1"); 
                        String connectPort = forwardOptions.replaceFirst("HTTPSPROXYconnect\\s*[(]\\s*(\\S+)[:]([0-9]+)\\s*[)]\\s*", "$2");

                        String connMsg = replaceAll(Config.proxyConnect, "${host}", connectHost);
                        connMsg = replaceAll(connMsg, "${port}", connectPort);
                        setPeek(connMsg.getBytes());
                        skipFirstServerData = true;
                }

                if ((forwardOptions!=null) && (forwardOptions.equals("HTTPrewritehost")))
                        rewriteHTTP();

                forwardSocket = new Socket (forwardHost, forwardPort);
                String forwardInfo = forwardHost + ":" + forwardPort;
                synchronized(usedConnections) {
                        usedConnections.put(forwardSocket, remoteInfo);
                }

                InputStream sin = forwardSocket.getInputStream();
                OutputStream sout = forwardSocket.getOutputStream();

                if (skipFirstServerData)
                        receiveData(sin, 30);

                if (peek != null)
                        sout.write(peek);

                TunnelThread a = new TunnelThread (cin, sout, remoteInfo + "->" + forwardInfo);
                a.setDaemon(true);
                a.start();
                TunnelThread b = new TunnelThread (sin, cout, forwardInfo + "->" + remoteInfo);
                b.setDaemon(true);
                b.start();
        }
        
        
        private String replaceAll(String text, String search, String replace) {
                StringBuffer result = new StringBuffer();
                int pos = 0;
                int next = text.indexOf(search, pos);
                while (next != -1) {
                        result.append(text.substring(pos, next)).append(replace);
                        pos = next + search.length();
                        next = text.indexOf(search, pos);
                }
                result.append(text.substring(pos));
                return result.toString();
        }

        private String getNowString() {
                Date now = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String result = sdf.format(now);
                return result;
        }

        public static void showStatus() {
                
                synchronized(usedConnections) {
                        Iterator iterator = usedConnections.keySet().iterator();
                        while (iterator.hasNext()) {
                                Socket key = (Socket)iterator.next();
                                String info = (String) usedConnections.get(key);
                                String fwdMsg = "?";
                                InetAddress fwdAddr = key.getInetAddress();
                                if (fwdAddr != null) {
                                        if (Config.loghostname) 
                                                fwdMsg = fwdAddr.getHostAddress() + ":" + key.getPort();
                                        else
                                                fwdMsg = fwdAddr.getHostAddress() + "(" + fwdAddr.getHostName() + ")" + ":" + key.getPort();
                                }
                                if (key.isClosed())
                                        fwdMsg += " (closed)";
                                System.out.println(info + " -> " + fwdMsg);
                        }
                }
                System.out.println("-end status");
        }

        public void setForward(String fwdHost, int fwdPort, String fwdOptions) {
                forwardHost = fwdHost;
                forwardPort = fwdPort;
                forwardOptions = fwdOptions;
        }

        public String getFwdHost() {
                return forwardHost;
        }
        public int getFwdPort() {
                return forwardPort;
        }

        public long getIP() {

                if (remoteIP == -1) {
                        byte[] bs = remoteAddr.getAddress();
                        long ip = 0;
                        for (int i=0; i<4; i++) {
                                long n = bs[i];
                                if (n < 0)
                                        n += 256;
                                ip = (ip << 8) + n;
                        }
                        remoteIP = ip;
                }
                return remoteIP;
        }

        public int getPort() {
                return remotePort;
        }

        public int getProxyPort() {
                return proxyPort;
        }

        public String getHost() {
                String result = remoteAddr.getHostAddress();
                return result;
        }


        public String getProxyHost() {
                return proxyHost;
        }

        

}
