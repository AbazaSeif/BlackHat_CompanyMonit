/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import net.sf.tcpswitch.parser.PListenerList;
import net.sf.tcpswitch.parser.Parser;

public class TCPSwitch {


        private static void usage(String msg) {
                System.err.println(msg);
                System.err.println("USAGE:");
                System.err.println("  tcpswitch [-config=<fiel>] [-daemon] [-loghostname] [-debug]");
                System.err.println("    -daemon: do not enter interactive mode");
                System.err.println("    -loghostname: log hostname in addition to ip address");
                System.err.println("    -debug:  verbose logging");
                System.err.println("URL: http://sourceforge.net/projects/tcpswitch");
        }

        public static void main(String[] args) {

                Logger.init();
                try {
                        for (int i=0; i<args.length; i++) {
                                String arg = args[i];
                                if (arg.startsWith("-config="))
                                        Config.configFile = getStringArg(arg);
                                else if (arg.startsWith("-daemon"))
                                        Config.daemon = true;
                                else if (arg.startsWith("-loghostname"))
                                        Config.loghostname = true;
                                else if (arg.startsWith("-debug"))
                                        Config.debug = true;
                                else
                                        throw new Exception("invalid arg '" + arg + "'");
                        }
                }
                catch (Exception e) {
                        usage(e.getMessage());
                        return;
                }

                Logger.log("TCPSwitch started");
                Logger.log("-----------------");

                PListenerList listeners = null;
                Parser parser = null;
                try {
                        FileInputStream fis = new FileInputStream(Config.configFile);
                        parser = new Parser(fis);
                        listeners = parser.getNextListenList();
                        fis.close();
                        System.out.println(listeners.show());
                        listeners.startListeners();

                        if (Config.daemon) {
                                // infinite loop
                                while (Config.daemon)
                                        Thread.sleep(1000);
                        }

                        System.out.println("Enter 'quit' to stop tcpswitch");
                        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
                        String cmd;
                        while (true) {
                                cmd = in.readLine();
                                if (cmd.equals("quit")) 
                                        break;
                                else if (cmd.equals("status"))
                                        ConnInfo.showStatus();
                                else if (cmd.equals("reconfig")) {
                                        Parser newParser = null;
                                        PListenerList newListeners = null;
                                        try {
                                                fis = new FileInputStream(Config.configFile);
                                                newParser = new Parser(fis);
                                                newListeners = parser.getNextListenList();
                                                fis.close();
                                        }
                                        catch (Exception e) {
                                                Logger.err("reconfig failed");
                                                if (newParser != null)
                                                        Logger.err("parsed lines: " + parser.getParsedLines());
                                                e.printStackTrace();
                                                newListeners = null;
                                        }
                                        if (newListeners != null) {
                                                listeners.stopListeners();
                                                parser = newParser;
                                                listeners = newListeners;
                                                System.out.println(listeners.show());
                                                listeners.startListeners();
                                        }
                                }
                                else if (cmd.equals("help"))
                                        System.out.println("valid commands are: 'quit', 'status', 'reconfig', 'help'");
                                else {
                                        System.out.println("unknown command, try 'quit' to exit or 'help' for list");
                                }
                        }
                } 
                catch (Exception e) {
                        if (parser != null)
                                Logger.err("parsed lines: " + parser.getParsedLines());
                        e.printStackTrace();
                }
                if (listeners != null)
                        listeners.stopListeners();
                System.out.println("finished!");
        }



        private static int getNumber(String value, String info) throws Exception {
                int result;
                try {
                        result = Integer.parseInt(value);
                }
                catch (Exception e) {
                        throw new Exception("invalid number: " + info);
                }
                return result;
        }

        private static String getStringArg(String arg) throws Exception {
                
                int pos = arg.indexOf("=");
                if (pos == -1)
                        throw new Exception("invalid arg '" + arg + "'");
                String result = arg.substring(pos + 1);
                return result;
        }

        private static int getNumberArg(String arg) throws Exception {

                String value = getStringArg(arg);
                int result = getNumber(value, "arg '" + arg + "'");
                return result;
        }



}
