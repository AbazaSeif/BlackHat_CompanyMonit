/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch.parser;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import net.sf.tcpswitch.Config;
import net.sf.tcpswitch.Logger;
import net.sf.tcpswitch.SwitcherThread;

public class PListener extends Thread {

        private int port;
        InetAddress bindAddr = null;
        private PStatementList statementList;

        private ServerSocket serverSocket = null;

        public PListener(String port, String bind, PStatementList statementList) {
                this.port = Integer.parseInt(port);
                this.statementList = statementList;
                if (bind != null) {
                        try {
                                bindAddr = InetAddress.getByName(bind);
                        } catch (UnknownHostException e) {
                                Logger.err("invalid bind address " + bind );
                        }
                }
        }

        public String show(String indent) {
                StringBuffer result = new StringBuffer();
                result.append(indent + "listen (" + Integer.toString(port) + ") {\n");
                result.append(statementList.show(indent + "  "));
                result.append(indent + "}\n");
                return result.toString();
        }

        public String getBindAddr() {
                return null;
        }

        public void startListener() {

                if (!Config.daemon) 
                        setDaemon(true);
                start();        
        }
        
        public void stopListener() {

                if (isAlive()) {
                        try {
                                interrupt();
                        } catch (Exception ignore) {}
                        try {
                                serverSocket.close();
                        } catch (Exception ignore) {}
                        serverSocket = null;
                        Logger.log("Listener at port " + Integer.toString(port) + " stopped.");
                }
        }
        

        public void run() {

                try {
                        serverSocket = new ServerSocket(port, 100, null);
                        Logger.log("Listening on port " + port);
                        
                        while (!isInterrupted()) {
                                Socket clientSocket = serverSocket.accept();
                                
                                SwitcherThread st = new SwitcherThread(clientSocket, statementList);
                                st.setDaemon(true);
                                st.start();
                        }
                } catch (Exception e){
                        e.printStackTrace();
                }

                
        }

        public int getPort() {
                return port;
        }


        
}
