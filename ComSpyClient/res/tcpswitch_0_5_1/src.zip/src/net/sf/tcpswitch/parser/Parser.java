/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch.parser;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Parser {

        private final static int ST_NONE = 0;
        private final static int ST_SPACE = 1;
        private final static int ST_COMMENT = 2;
        private final static int ST_ALPHA = 3;
        private final static int ST_NUM = 4;

        private InputStream in;
        private int state;
        private byte[] buffer;
        private int bufpos;
        private int bufsize;

        private int lastChar; 
        private int thisChar; 
        private int nextChar; 
        
        private int nextUChar;
        
        private int parsedLines;
        
        public Parser(InputStream in) {
                this.in = in;
                state = ST_SPACE;
                buffer = new byte[4096];
                bufpos = 0;
                bufsize = 0;
                lastChar = -1; 
                thisChar = -1; 
                nextChar = -1;
                parsedLines = 0;
                getNextChar(); 
                nextUChar = -1;
                getNextUncommentedChar();
        }

        private int getNextBuf() {
                int result = -1;
                if (bufpos >= bufsize) {
                        bufpos = 0;        
                        try {
                                bufsize = in.read(buffer);
                        } catch (IOException e) {
                                bufsize = -1;
                        }
                }
                if (bufpos < bufsize) {
                        result = buffer[bufpos];
                        bufpos += 1;
                        if (result < 0)
                                result = 256 + result; 
                }
                return result;
        }

        private int getNextChar() {
                lastChar = thisChar;
                thisChar = nextChar;
                nextChar = getNextBuf();
                if (thisChar == '\n')
                        parsedLines += 1;
                return thisChar;
        }

        private int getNextUncommentedChar() {
                
                int peekUChar; 
                while (true) {
                        peekUChar = getNextChar();
                        if ((thisChar == '/') && (nextChar == '*')) {
                                while (peekUChar != -1) {
                                        peekUChar = getNextChar();
                                        if ((peekUChar == '/') && (lastChar == '*'))
                                                break; 
                                }
                                if (peekUChar != -1)
                                        continue;
                        }
                        if (thisChar == '#') {
                                while (peekUChar != -1) {
                                        peekUChar = getNextChar();
                                        if (peekUChar == '\n')
                                                break; 
                                }
                                if (peekUChar != -1)
                                        continue;
                        }
                        if (thisChar == '\r') 
                                continue;
                        break;
                }
                int result = nextUChar;
                nextUChar = peekUChar;
                return result;
        }

        private String getLine() {
                StringBuffer result = new StringBuffer();
                int c = getNextUncommentedChar();
                if (c == -1)
                        return null;
                while (c != -1) {
                        if (c == '\n')
                                break;
                        result.append((char)c);
                        c = getNextUncommentedChar();
                }
                return result.toString();
        }

        private void skipSpaces() {
                
                while (nextUChar != -1) {
                        if (nextUChar > ' ')
                                break;
                        getNextUncommentedChar();        
                }
        }

        private boolean readNext(int chk) {
                boolean ok = false;
                skipSpaces();
                if (nextUChar == chk) {
                        ok = true;
                        getNextUncommentedChar();
                }
                return ok;
        } 

                        
        private String getAlphaNum() { 
                
                StringBuffer result = new StringBuffer();
                while (nextUChar != -1) {
                        if (  (nextUChar >= 'a') && (nextUChar <= 'z')                         
                           || (nextUChar >= 'A') && (nextUChar <= 'Z')                         
                           || (nextUChar >= '0') && (nextUChar <= '9')) 
                        {                         
                                result.append((char)getNextUncommentedChar());                        
                        }
                        else {
                                break;
                        }
                }
                return result.toString();
        }

        private String readOperator() { 
                
                StringBuffer result = new StringBuffer();
                while (nextUChar != -1) {
                        if (  (nextUChar == '<') || (nextUChar == '=')                         
                           || (nextUChar == '>') || (nextUChar == '!')) 
                        {                         
                                result.append((char)getNextUncommentedChar());                        
                        }
                        else {
                                break;
                        }
                }
                return result.toString();
        }

        private String readUntil(int end) { 
                
                StringBuffer result = new StringBuffer();
                while (nextUChar != -1) {
                        if (nextUChar == end) {
                                getNextUncommentedChar();
                                break;                         
                        }
                        result.append((char)getNextUncommentedChar());                        
                }
                return result.toString();
        }

        private String readNonSpaces() { 
                
                StringBuffer result = new StringBuffer();
                while (nextUChar != -1) {
                        if (nextUChar <= ' ')
                                break;                         
                        result.append((char)getNextUncommentedChar());                        
                }
                return result.toString();
        }

        private PStatement getNextStatement() throws Exception {
                
                PStatement result = null;
                skipSpaces();
                String statement = getAlphaNum();
                if (statement.equals("check")) {
                        readNext('(');
                        readNext('$');
                        String var = getAlphaNum();
                        skipSpaces();
                        String op = readOperator();
                        skipSpaces();
                        String value = readUntil(')');
                        value = value.trim();
                        readNext('{');
                        PStatementList statementList = getNextStatementList();
                        result = new PCheck(var, op, value, statementList);
                        readNext('}');
                }
                else if (statement.equals("forward")) {
                        skipSpaces();
                        String params = readNonSpaces();
                        result = new PForward(params);
                }
                else if (statement.equals("reject")) {
                        result = new PReject();
                }
                else {
                        throw new Exception("ERROR: illegal statement: " + statement + getLine());
                }
                return result;
        }

        private PStatementList getNextStatementList() throws Exception {
                
                PStatementList statementList = new PStatementList();
                skipSpaces();
                while ((nextUChar != -1) && (nextUChar != '}')) {
                        PStatement statement = getNextStatement();
                        statementList.add(statement);
                        skipSpaces();
                }
                return statementList;
        }

        private PListener getNextListen() throws Exception {
                
                skipSpaces();
                String listen = getAlphaNum();
                PListener result = null;
                if (listen.equals("listen")) {
                        readNext('(');
                        skipSpaces();
                        String ports = readUntil(')');
                        ports = ports.trim();
                        readNext('{');
                        PStatementList sublist = getNextStatementList();
                        result = new PListener(ports, null, sublist);
                        readNext('}');
                }
                else {
                        throw new Exception("ERROR: illegal listener : " + listen + getLine());
                }
                return result;
        }

        public PListenerList getNextListenList() throws Exception {
                
                PListenerList result = new PListenerList();
                skipSpaces();
                while ((nextUChar != -1) && (nextUChar != '}')) {
                        PListener listen = getNextListen();
                        result.add(listen);
                        skipSpaces();
                }
                return result;
        }

        public static void main(String[] args) {
                
                try {
                        FileInputStream fis = new FileInputStream("u:\\opt\\eclipse211\\workspace\\tcpswitch\\tcpswitch.config");
                        Parser parser = new Parser(fis);
                        PListenerList listeners = parser.getNextListenList();
                        System.out.println(listeners.show());
                } catch (Exception e) {
                        e.printStackTrace();
                }
                
        }

        public int getParsedLines() {
                return parsedLines;
        }

}
