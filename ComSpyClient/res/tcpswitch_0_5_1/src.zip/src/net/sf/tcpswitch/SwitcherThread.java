/*******************************************************************************
 * Copyright (c) 2004 Ferenc Hechler - ferenc_hechler@users.sourceforge.net
 * 
 * This file is part of the TCP-Switch application
 *
 * The TCP-Switch application is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 * 
 * The TCP-Switch application is distributed
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with the TCP-Switch application;
 * if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************************************************************************/
package net.sf.tcpswitch;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import net.sf.tcpswitch.parser.PStatement;
import net.sf.tcpswitch.parser.PStatementList;


public class SwitcherThread extends Thread {

	private Socket clientSocket;
        private PStatementList statementList;
	
	public SwitcherThread(Socket clientSocket, PStatementList statementList) {
                
                this.clientSocket  = clientSocket;
                this.statementList = statementList;
	}
        
	
	public void run() {
                
		try {
                        ConnInfo conn = new ConnInfo(clientSocket);
                        int status = statementList.forward(conn);
                        if (status == PStatement.EX_FINISHED)
                                conn.forward();
                        else {
                                Logger.log("connection rejected");
                                clientSocket.close();
                                clientSocket = null;
                        }
                        
                }
                catch (Exception e) {
                        Logger.log("connection ERROR: " + e.getMessage());
                        try {
                                clientSocket.close();
                        } catch (IOException ignore){}
                        clientSocket = null;
                }
	}

        private String getFirstData(String host, int port) {

                String result = null;
                byte[] buf;
                try {
                        Socket st = new Socket(host, port);
                        InputStream sin = st.getInputStream();
                        OutputStream sout = st.getOutputStream();
                        buf = receiveData(sin, 30);
                        sout.close();
                        sin.close();
                        st.close();
                        result = new String(buf);
                } catch (Exception e) {
                        Logger.err("getFirstData(" + host + ", " + port + "): error=" + e.getMessage());
                }
                return result; 
        }

        private void sendData(OutputStream cout, byte[] buf) throws IOException {
                cout.write(buf);                
                Logger.dump("sendData", buf, 0, buf.length);
        }
        
        private byte[] receiveData(InputStream cin, int wait) throws IOException, InterruptedException {
                byte[] buf = null;
                int cnt = wait;
                while (cin.available() == 0) {
                        Thread.sleep(100);
                        cnt -= 1;
                        if (cnt == 0)
                                break;
                }
                if (cin.available() > 0) {
                        buf = new byte[cin.available()];
                        cin.read(buf);
                }
                if (buf != null)
                        Logger.dump("receiveData", buf, 0, buf.length);
                else
                        Logger.debug("receiveData: null");
                return buf;
        }
        
        
}
