import javax.servlet.*;
import javax.servlet.http.*;            
import java.io.*;



public class make_new_folder extends HttpServlet
{
   public void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
   {
	  String user_id,user,temp,filename;
	  int i;
	  boolean flag=true;
      response.setContentType("Text/html");
      PrintWriter out = response.getWriter();
		user_id= request.getParameter("user_id");
		filename= request.getParameter("name");
		filename=filename.trim();
		i=user_id.indexOf("@");
		user=user_id.substring(0,i);


			FileReader fr=new FileReader("C://jsdk2.1/webpages/WEB-INF/servlets/"+user+"/files.txt");
			BufferedReader br1=new BufferedReader(fr);

			out.println("<html><head><body bgcolor=\"#CECFC5\">");
			  out.println("<table border=0><tr><td ROWSPAN=2><strong><font size=4 color=\"red\">Mail Box&nbsp;&nbsp;&nbsp;&nbsp;</font></strong></td>");
			  out.println("<td ROWSPAN=2><font size=4 color=\"blue\">"+user_id+"</font></td></tr>");
			  out.println("<td><form method=post action=\"http://127.0.0.1:8080/servlet/mailserver1\"><input type=submit value=\"logout\" ></form></td>");
			 out.println("<tr><td><form method=post action=\"http://127.0.0.1:8080/servlet/inbox\"><input type=hidden name=\"fname\" value=\"inbox\"><input type=submit value=\"Inbox&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\" >");
			 out.println("<input type=hidden name=\"user_id\" value="+user_id+"></form>");
			  out.println("<tr><td><form method=post action=\"http://127.0.0.1:8080/servlet/compose\"><input type=submit value=\"Compose\" ><input type=hidden name=\"user_id\" value="+user_id+"></form></td>");
			  out.println("<td><font size=4 color=\"red\">Welcome to your Options Area.</font> </td>");
			  out.println("<tr><td><form method=post action=\"http://127.0.0.1:8080/servlet/options\"><input type=submit value=\"Options&nbsp;&nbsp;&nbsp;&nbsp;\" >");			  out.println("<input type=hidden name=\"user_id\" value="+user_id+"></form></td></tr>");
			  out.println("<tr><td ROWSPAN=19></td>");
			  out.println("<td ROWSPAN=19></table>");
			  if (filename.equals(""))
								out.println("<P><BR><BR> Enter the name at least 1 character long.");
			  else
	   {
			  	   	   try{
						while((temp=br1.readLine())!=null)
						{		
							if(temp.equalsIgnoreCase(filename))
								flag=false;
					   }
					   if(flag)
						   {
						   FileWriter fw=new FileWriter("C://jsdk2.1/webpages/WEB-INF/servlets/"+user+"/files.txt",true);
						   fw.write(filename+"\n");
						   fw.close();
						    fw=new FileWriter("C://jsdk2.1/webpages/WEB-INF/servlets/"+user+"/"+filename+".txt");
							fw.close();
							out.println("<P><BR><BR> The folder "+filename+" successfully created!!!");
						   }
						   else
						   {
							out.println("<P><BR><BR> The folder "+filename+" already exists!!");
						   }
					   }

			catch(Exception sa)
						   {
				System.out.println(sa);
						   }
	   }
			out.println("</body></html>");
			fr.close();
}
}